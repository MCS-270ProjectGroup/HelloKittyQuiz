package com.example.geoquiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast

private lateinit var trueButton: Button
//Accessing a lateinit property before it has been
// initialized throws a special exception that clearly
// identifies the property being accessed and the fact
// that it hasn't been initialized.

// if we just declare button we will get an error if it hasn't bee
// initialized
private  lateinit var  falseButton: Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        trueButton = findViewById(R.id.true_button)
        falseButton = findViewById(R.id.false_button)

        trueButton.setOnClickListener {
            // do something in response to true button beling clicked
            // what to do is pop a true toast
            // if user press true button, then pop a toast that say this is correct
            // because Hello Kitty's bf is dear daniel
            // We need to use Toast class, just call it
            // context, id, duration
            // finally call the show method
            Toast.makeText(this, R.string.correct_toast, Toast.LENGTH_LONG).show()
        }
        falseButton.setOnClickListener {
            // do soething in response to false button being clicked
            // pop a false toast
            // if user press true button, then pop a toast that say this is incorrect
            Toast.makeText(this, R.string.incorrect_toast, Toast.LENGTH_LONG).show()

        }
    }
}